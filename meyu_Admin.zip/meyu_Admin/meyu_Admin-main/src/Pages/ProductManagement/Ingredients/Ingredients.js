import React from "react";
import IngredientsTable from "../../../Components/Common/Table/IngredientsTable/IngredientsTable";

const Ingredients = () => {
  return (
    <div>
      <IngredientsTable />
    </div>
  );
};

export default Ingredients;
