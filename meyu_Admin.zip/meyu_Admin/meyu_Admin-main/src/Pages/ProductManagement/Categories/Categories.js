import React from "react";
import CategoriesTable from "../../../Components/Common/Table/CategoriesTable/CategoriesTable";

const Categories = () => {
  return (
    <div>
      <CategoriesTable />
    </div>
  );
};

export default Categories;
