import React from "react";
import { DashboardCard } from "../../Components/Common/Cards/DashboardCard/DashboardCard";
import { ReactComponent as Home } from "../../Assets/Icon/home.svg";
import "./Dashboard.scss";
import "../../Components/Common/DatePicker/Datepickbutton.scss";

const Dashboard = () => {
  return (
    <>
      <div className="dashboard-wrapper d-flex justify-content-between align-items-center">
        <div className="page-heading d-flex p-4">
          <div className="page-heading-wapper align-items-center d-flex">
            <Home className="page-icon m-0" />
            <h3 className="page-sec-heading m-0 mx-2">Dashboard</h3>
          </div>
        </div>
      </div>
      <div className="dashboard-content">
        <DashboardCard />
      </div>
    </>
  );
};

export default Dashboard;
