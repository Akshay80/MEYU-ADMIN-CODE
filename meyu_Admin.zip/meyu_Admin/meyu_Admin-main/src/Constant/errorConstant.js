const errorConstant = {
    "invalidEmail" : "Invalid Email ID",
    "fieldRequired" : "Field Cannot be empty."
}