import React, {useState, useEffect} from "react";
import UserImage from "../../../../../Assets/Images/blank-user.png";
import "./Card.scss";
import { discontinueCustomer } from "../../../../../Services/customerServices";
import { toast } from "react-toastify";
import { confirmAlert } from "react-confirm-alert";
import "react-confirm-alert/src/react-confirm-alert.css";
import { imageUrl } from "../../../../../config/settings/env";
import Skeleton from "react-loading-skeleton";
import "react-loading-skeleton/dist/skeleton.css";

const CustomerCard = ({
  customerDetail,
  customerImage,
  customerId,
  customerVerify,
  customerReject,
  totalCompleteOrders,
  totalAmount,
}) => {
  const [disState, setDisState] = useState(localStorage.getItem("isCustVerified"));

  useEffect(() => {
    setDisState(`${customerVerify}`);
  }, [customerVerify]);

  async function disCustomer() {
    if (`${disState}` === "false") {
      setDisState("true");
    } else {
      setDisState("false");
    }
    var params = {
      isVerified: disState === "false"? "true": "false",
    };
    await discontinueCustomer(customerId, params)
      .then((res) => {
        if (res.data.data.message === "User profile verified successfully.") {
          toast.success(res.data.data.message, {
            position: "top-right",
            autoClose: 3000,
            hideProgressBar: true,
            closeOnClick: true,
            pauseOnHover: true,
            draggable: false,
            progress: 0,
          });
        }

        if (res.data.data.message === "User profile rejected successfully.") {
          toast.error(res.data.data.message, {
            position: "top-right",
            autoClose: 3000,
            hideProgressBar: true,
            closeOnClick: true,
            pauseOnHover: true,
            draggable: false,
            progress: 0,
          });
        }
      })
      .catch(function (err) {
        console.log(err);
      });
  }

  const disContinue = () => {
    confirmAlert({
      title: disState === "true"? "Discontinue!": "Continue?",
      message:  `Are you sure you want to ${disState === "true"? "discontinue with": "continue with"} ${customerDetail.firstName + " " +customerDetail.lastName}?`,
      buttons: [
        {
          label: "Yes",
          className: "btn btn-success",
          onClick: () => disCustomer(),
        },
        {
          label: "No",
          className: "btn btn-success",
        },
      ],
    });
  };

  var testStr = customerImage;
  var splitStr = testStr.substring(testStr.indexOf(imageUrl) + 20);

  return (
    <div className="container">
      <div className="card mb-3 p-3">
        <div className="row g-0">
          <div className="col-md-3 col-sm-12 align-items-center justify-content-center">
            <div className="d-flex align-items-center justify-content-center">
              {customerImage === "" ? (
                <Skeleton
                  circle
                  height={100}
                  width={100}
                  containerClassName="avatar-skeleton"
                />
              ) : customerImage.includes(
                  "https://lh3.googleusercontent.com"
                ) === true ? (
                <img
                  src={splitStr}
                  className="img"
                  alt="..."
                  style={{ borderRadius: "50%", width: 100, height: 100 }}
                />
              ) : (
                <img
                  src={
                    customerImage === `${imageUrl}null` ||
                    customerImage.includes(
                      "https://lh3.googleusercontent.com"
                    ) === true
                      ? UserImage
                      : customerImage
                  }
                  className="img"
                  alt="..."
                  style={{ borderRadius: "50%", width: 100, height: 100 }}
                />
              )}
            </div>
          </div>
          <div className="col-md-9 col-sm-12">
            <div>
              <div className="user-card-info d-flex mx-3 mt-2 align-items-center justify-content-between">
                <div className="info-x">
                  {Object.keys(customerDetail).length === 0 ?
                  <><h5 className="mb-1"><Skeleton width={100} /></h5>
                  <Skeleton  width={200} count={4}/>
                  </>
                  : (
                    <>
                      <h5 className="mb-1">
                        {customerDetail?.firstName} {customerDetail?.lastName}
                      </h5>
                      <p>{customerDetail?.phone}</p>
                      <p>{customerDetail?.email}</p>
                      <p>{customerDetail?.Address?.street}</p>
                      <p>{customerDetail?.Address?.city}</p>
                    </>
                  )}
                </div>
                <div className="d-flex align-self-start">
                  <button
                    className={
                      disState === "true"
                        ? "btn btn-success shadow-none"
                        : "btn btn-danger shadow-none"
                    }
                    type="button"
                    onClick={() => disContinue()}
                  >
                    {disState === "true" ? "Approved" : "Disapproved"}
                  </button>
                </div>
              </div>

              <div className="primary-card-info mx-3 mt-5 d-flex justify-content-between">
                <div className="info-xz">
                  <h5 className="mb-0">Completed Order</h5>
                  <h6>{totalCompleteOrders}</h6>
                </div>
                <div className="info-xz">
                  <h5 className="mb-0">Total Amount</h5>
                  <h6>{`$${totalAmount === null ? 0 : totalAmount}`}</h6>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CustomerCard;
