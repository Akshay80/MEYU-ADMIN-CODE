export const AllItemsData = [
    {
      id: "#5562345",
      date: `26th Jan 2021`,
      name: "Olivia Shine",
      product: "Dal makhani",
      status: "Pending"
    },
    {
      id: "#5563639",
      date: "26th Jan 2021",
      name: "Samantha Bake",
      product: "Stuffed paratha",
      status: "Decline"
    },
    {
      id: "#5568956",
      date: "22nd Dec 2020",
      name: "Roberto Carlo",
      product: "Masala dosa",
      status: "Approved"
    },
    {
      id: "#5563489",
      date: "25 Oct 2020",
      name: "James WItcwicky",
      product: "Vada pav",
      status: "Approved"
    },
    {
      id: "#5562772",
      date: "2nd October",
      name: "Eminem Rawat",
      product: "Idli",
      status: "Decline"
    },
  ];
  