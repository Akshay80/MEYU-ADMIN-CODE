export const OrdersData = [
    {
      id: "#5552311",
      date: `18 Oct 2021 12:26 PM`,
      customername: "Airi Satou",
      chefname: "Olivia Shine",
      amount: "S$ 82.46",
      status: "Pending"
    },
    {
      id: "#5552322",
      date: "18 Oct 2021 10:35 AM",
      customername: "Angelica Ramos",
      chefname: "Samantha Bake",
      amount: "S$ 11.22",
      status: "Delievered"
    },
    {
      id: "#5552323",
      date: "18 Oct 2021 10:20 AM",
      customername: "Ashton Cox",
      chefname: "Roberto Carlo",
      amount: "S$ 22.18",
      status: "Cancelled"
    },
    {
      id: "#5552349",
      date: "18 Oct 2021 09:10 AM",
      customername: "Bradley Greer",
      chefname: "James WItcwicky",
      amount: "S$ 34.41",
      status: "Delievered"
    },
    {
      id: "#5563424",
      date: "1 Oct 1995 1:00 PM",
      customername: "Brad White",
      chefname: "Samantha Bake",
      amount: "S$ 62.01",
      status: "Cancelled"
    },
  ];
  