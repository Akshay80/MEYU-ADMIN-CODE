import React from 'react';

export const Loader = () => (
    <div className="spin"></div>
)