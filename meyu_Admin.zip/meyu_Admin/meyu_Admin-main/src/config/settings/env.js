export const development = {
  api: {
    url: "https://api.meyu.sg/api/",
    mode: "cors",
  },
};

export const staging = {
  api: {
    url: "https://api.meyu.sg/api/",
    mode: "cors",
  },
};

export const imageUrl = "https://api.meyu.sg/";
